
## Reuniões

Data|Horário|Assunto|link
---|---|---|---
02/07|13:30|Pedagógico Semanal com Coordenadora Graciela|[Google Meet](https://meet.google.com/qiq-itsw-tza)

[Página inicial](../index.md)