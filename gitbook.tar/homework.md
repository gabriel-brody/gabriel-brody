---
layout: default
title: Lições de Casa
---

## Lições de Casa

Data|Matéria|Conteúdo|Data de entrega|Observação
---|---|---|---|---
24/11|Math|Folha Avulsa 7|01/12|
24/11|Geografia|Livro de geografia pág. 125 (exerc. 5)|01/12|
25/11|Science|Folha Avulsa 6|09/12|
26/11|Language|Livro de Language, página 110, letra C|03/12|
26/11|História|Livro de história pág. 132|03/12|
27/11|Ética|Livro de Ética pág. 43|04/12|
27/11|Math|Folha Avulsa 8|04/12|

[Voltar](../)
