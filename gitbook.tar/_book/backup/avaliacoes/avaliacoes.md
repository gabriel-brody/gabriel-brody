## Ciclo Avaliativo Digital

Data|Matéria|Conteúdo|Data de entrega
--|--|--|--
06/07|Matemática|Unidade 3- Mental Calculation p. 29-40|13/07
07/07|Ciências|Unidade 1- Life Processes p. 4-27|14/07
08/07|Português|Unidade 2- Capítulo 1: Saúde mesmo; O adjetivo p. 104-108; Capítulo 2: Tempo de chuva?;Tempo bom!; Infográfico p. 124-126; A receita p. 127-129|15/07
09/07|História e Geografia|História; Unidade 2- A formação das cidades; Capítulo 1: Os primeiros grupos p. 44-47; Capítulo 2: Das vilas às cidades p. 50-53; Geografia Unidade 2- O espaço rural; Capítulo 1: Paisagens rurais p. 38-47|16/07
10/07|Inglês|Unidades 1, 2 e 3; Nouns, Verbs, Adjectives, Tenses (Present and Past), Prefixes Vocabulário|17/07

[Página inicial](../index.md)