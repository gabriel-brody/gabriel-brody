---
layout: default
title: Turma 3º ano C
---

## Página para organizar as atividades da turma 3º ano C, não isentando a necessidade dos pais lerem os comunicados. As atividades das matérias extracurriculares não serão postadas neste site.

