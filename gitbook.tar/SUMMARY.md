# Summary

* [Início](README.md)
* [Lições de casa](homework.md)
* [Roteiro de estudo](roteiro_estudo.md)
* [Avaliações](avaliacoes.md)
* [Reuniões](reunioes.md)
* [Horário de aulas](horario_aulas.md)
