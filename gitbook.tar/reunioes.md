---
layout: default
title: Reuniões
---

## Reuniões

Data|Horário|Assunto|link
--|--|--|--
03/12|13:30|Pedagógico Semanal com a coordenadora Graciela|[Google Meet](https://meet.google.com/qiq-itsw-tza)


[Voltar](../)
