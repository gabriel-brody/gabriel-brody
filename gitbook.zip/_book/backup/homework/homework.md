
## Lições de casa

Data|Matéria|Atividade|Entrega|Observação
---|---|---|---|---
29/06|Language|E-book Literário 2 pág. 28|06/07|
29/06|Português|E-book Literário págs. 12 e 13|30/06|
30/06|Math|Homework 6 - Progresso Plus: página 27- exercícios 6 e 7|07/07|
30/06|Geografia|Livro pág. 88|07/07|
01/07|Science|Homework 4 - Livro de Science - página 39 (Atividade Avaliativa)|08/07|Enviar pelo Classroom
01/07|Português - Produção de texto|E-Book literário págs. 14 a 16|02/07|
02/07|Language|Folha avulsa sobre “More Prefixes” (Atividade Avaliativa)|09/07
02/07|História|Livro de história pág. 71 (exercícios 7 e 8) e págs 72 e 73|09/07
03/07|Math|Livro de Matemática: página 40 (Atividade Avaliativa)|10/07|Enviar pelo Classroom
03/07|Português|E-book literário pág. 17|06/07

[Página inicial](../index.md)
